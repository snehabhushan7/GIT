import hello_world

printHelloWorld()
