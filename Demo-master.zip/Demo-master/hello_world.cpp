#include <iostream>

// BCG Demo
// Second Commnet
int main()
{
  std::cout << "Hello World !!" << std::endl;

  int x = 20;
  for(int idx = 0; idx < 100; ++idx)
    x++;
  
  return 0;
}
