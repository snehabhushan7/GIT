def printHelloWorld():
    print "Hello World!!"
    print "Line2"


if __name__ == "__main__":
    printHelloWorld()
    
