class Arrow
{
 public:
 Arrow();
 void Print();


};
