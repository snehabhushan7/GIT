#include<iostream>
#include"Arrow.h"
using namespace std;

Arrow::Arrow()
{
 }
void Arrow::Print()
{
  cout<<"Idi naa maata..!!Naa maate Shaasanam..!!Jai Maahishmathi...!!"<<endl;
 }
