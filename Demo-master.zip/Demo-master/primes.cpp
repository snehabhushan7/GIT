#include <iostream>

//  Lets add the prime method
bool isPrime(const int input)
{
  // added this comment
  return true;
}

int main()
{
  isPrime(10);
  return 0;
}
